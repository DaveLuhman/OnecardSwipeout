module.exports = {
    preset: "jest-playwright-preset"
}