---
name: Feature
about: Request to merge a new feature 
---

**Short summary**

**Detailed description (motivation, use-case etc.)**

**Screenshots (if appropriate)**

**Checklist**

- [ ] My change requires a change to the documentation.
- [ ] I have updated the documentation accordingly.