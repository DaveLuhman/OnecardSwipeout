---
name: Bugfix
about: Request to merge a bugfix
---

**Short summary**

**Detailed description (motivation, use-case etc.)**

**Screenshots (if appropriate)**

**Checklist**

- [ ] My change requires a change to the documentation.
- [ ] I have updated the documentation accordingly.